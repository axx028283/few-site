/**
 * FEW SITE — API pública somente de leitura.
 * Este arquivo deve ficar em um PROJETO APPS SCRIPT SEPARADO do FEW MANAGER.
 * Não adicione este endpoint ao projeto privado do Manager.
 *
 * Instalação:
 * 1) Cole o ID da planilha em FEW_PUBLIC_SPREADSHEET_ID.
 * 2) Execute autorizarApiPublicaFEW() no editor uma vez.
 * 3) Implante como Aplicativo da Web: executar como você; acesso qualquer pessoa.
 * 4) Copie a URL /exec para config.js do FEW SITE.
 */
const FEW_PUBLIC_SPREADSHEET_ID = "COLE_AQUI_O_ID_DA_PLANILHA_DO_FEW_MANAGER";
const FEW_PUBLIC_STATE_SHEET = "_DB_STATE";
const FEW_PUBLIC_STATE_KEY = "PRIMARY_STATE";

function autorizarApiPublicaFEW() {
  if (!FEW_PUBLIC_SPREADSHEET_ID || FEW_PUBLIC_SPREADSHEET_ID.indexOf("COLE_AQUI") === 0) {
    throw new Error("Configure FEW_PUBLIC_SPREADSHEET_ID com o ID da planilha antes de executar.");
  }
  const ss = SpreadsheetApp.openById(FEW_PUBLIC_SPREADSHEET_ID);
  const sh = ss.getSheetByName(FEW_PUBLIC_STATE_SHEET);
  if (!sh) throw new Error("A aba _DB_STATE não foi encontrada. Inicialize o FEW MANAGER primeiro.");
  PropertiesService.getScriptProperties().setProperty("FEW_PUBLIC_SPREADSHEET_ID", FEW_PUBLIC_SPREADSHEET_ID);
  return "API pública autorizada. Planilha encontrada: " + ss.getName();
}

function doGet(e) {
  try {
    const props = PropertiesService.getScriptProperties();
    const spreadsheetId = props.getProperty("FEW_PUBLIC_SPREADSHEET_ID");
    if (!spreadsheetId) return outputFewPublic_({ ok:false, error:"API ainda não configurada." }, e);
    const ss = SpreadsheetApp.openById(spreadsheetId);
    const sh = ss.getSheetByName(FEW_PUBLIC_STATE_SHEET);
    if (!sh || sh.getLastRow() < 2) return outputFewPublic_({ ok:true, championships:[], updatedAt:null }, e);
    const rows = sh.getDataRange().getValues();
    const chunks = rows.slice(1).filter(function(r){ return String(r[0]) === FEW_PUBLIC_STATE_KEY; });
    if (!chunks.length) return outputFewPublic_({ ok:true, championships:[], updatedAt:null }, e);
    chunks.sort(function(a,b){
      const aa = String(a[3] || "1/1").split("/")[0];
      const bb = String(b[3] || "1/1").split("/")[0];
      return Number(aa) - Number(bb);
    });
    const raw = chunks.map(function(r){ return String(r[4] || ""); }).join("");
    const state = JSON.parse(raw);
    const championships = Array.isArray(state.championships) ? state.championships.map(sanitizeFewChampionship_) : [];
    return outputFewPublic_({ ok:true, championships:championships, updatedAt:chunks[0][1] ? String(chunks[0][1]) : null }, e);
  } catch (err) {
    return outputFewPublic_({ ok:false, error:"Não foi possível carregar os dados públicos." }, e);
  }
}

function sanitizeFewChampionship_(c) {
  const teams = Array.isArray(c.teams) ? c.teams.map(function(t){
    return {
      id: publicText_(t.id),
      name: publicText_(t.name),
      players: Array.isArray(t.players) ? t.players.map(function(p){
        return { id:publicText_(p.id), name:publicText_(p.name), pos:publicText_(p.pos) };
      }) : []
    };
  }) : [];
  const matches = Array.isArray(c.matches) ? c.matches.map(function(m){
    return {
      id:publicText_(m.id), phase:publicText_(m.phase), legLabel:publicText_(m.legLabel),
      round:m.round == null ? null : m.round, groupId:publicText_(m.groupId),
      homeId:publicText_(m.homeId), awayId:publicText_(m.awayId),
      homeScore:publicNumberOrNull_(m.homeScore), awayScore:publicNumberOrNull_(m.awayScore),
      status:publicText_(m.status), woWinnerId:publicText_(m.woWinnerId),
      goals:Array.isArray(m.goals) ? m.goals.map(sanitizeFewEvent_) : [],
      assists:Array.isArray(m.assists) ? m.assists.map(sanitizeFewEvent_) : []
    };
  }) : [];
  return {
    id:publicText_(c.id), name:publicText_(c.name), modality:publicText_(c.modality),
    format:publicText_(c.format), phase:publicText_(c.phase), status:publicText_(c.status),
    deadline:publicText_(c.deadline), bannerUrl:publicUrl_(c.bannerUrl), logoUrl:publicUrl_(c.logoUrl),
    teams:teams, matches:matches
  };
}

function sanitizeFewEvent_(item) {
  item = item || {};
  return {
    id:publicText_(item.id), playerId:publicText_(item.playerId || item.scorerId || item.assistId),
    playerName:publicText_(item.playerName || item.scorerName || item.assistName || item.name),
    teamId:publicText_(item.teamId), scorerId:publicText_(item.scorerId),
    scorerName:publicText_(item.scorerName), assistId:publicText_(item.assistId),
    assistName:publicText_(item.assistName)
  };
}

function publicText_(value) {
  if (value === null || value === undefined) return "";
  return String(value).slice(0, 300);
}
function publicNumberOrNull_(value) {
  if (value === null || value === undefined || value === "") return null;
  const n = Number(value);
  return isFinite(n) ? n : null;
}
function publicUrl_(value) {
  const url = publicText_(value);
  return /^https:\/\//i.test(url) ? url : "";
}
function outputFewPublic_(payload, e) {
  const callback = e && e.parameter ? String(e.parameter.callback || "") : "";
  const json = JSON.stringify(payload);
  if (callback) {
    if (!/^[A-Za-z_$][0-9A-Za-z_$\.]{0,100}$/.test(callback)) {
      return ContentService.createTextOutput("Invalid callback").setMimeType(ContentService.MimeType.TEXT);
    }
    return ContentService.createTextOutput(callback + "(" + json + ");")
      .setMimeType(ContentService.MimeType.JAVASCRIPT);
  }
  return ContentService.createTextOutput(json).setMimeType(ContentService.MimeType.JSON);
}
