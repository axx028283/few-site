# FEW SITE — Portal público

Projeto estático para GitHub Pages. O site é separado do FEW MANAGER e não contém funções administrativas.

## Conteúdo

- `index.html` — estrutura do portal.
- `style.css` — identidade visual responsiva preta e dourada.
- `app.js` — páginas, filtros, cartões, tabelas e estatísticas.
- `config.js` — URL da API pública e intervalo de atualização.
- `api/PUBLIC_API.gs` — serviço de leitura pública para instalar em um NOVO projeto Apps Script separado.

## Antes de publicar

O ZIP não inclui uma URL de API pronta, porque ela depende da planilha e da implantação da sua conta Google. O site abre em modo de prévia demonstrativa até configurar `apiUrl` em `config.js`.

### 1. Criar o serviço público de leitura

**Não coloque `PUBLIC_API.gs` dentro do projeto privado do FEW MANAGER.** Crie um projeto Apps Script independente em https://script.google.com/ e cole nele o conteúdo de `api/PUBLIC_API.gs`.

1. Abra a planilha que o FEW MANAGER usa. Copie o ID que fica entre `/d/` e `/edit` no endereço da planilha.
2. No arquivo `PUBLIC_API.gs`, substitua `COLE_AQUI_O_ID_DA_PLANILHA_DO_FEW_MANAGER` pelo ID copiado.
3. Salve e execute `autorizarApiPublicaFEW()` uma vez. Autorize o acesso à planilha.
4. Implante esse projeto separado como **Aplicativo da Web**.
5. Escolha **Executar como: Eu** e **Quem pode acessar: Qualquer pessoa**.
6. Copie a URL terminada em `/exec`.

Esse serviço separado só possui um `doGet` público e retorna uma lista permitida de dados esportivos. Não coloque funções de gravação, administração ou o código do Manager nesse projeto. O endpoint público expõe nomes de campeonatos, equipes, jogadores, partidas e resultados. Não compartilhe a planilha diretamente com o público.

### 2. Conectar o site

Abra `config.js` e substitua a URL vazia pela URL `/exec` do serviço público:

```js
window.FEW_CONFIG = {
  apiUrl: "COLE_A_URL_EXEC_AQUI",
  refreshSeconds: 15,
  federationName: "Federação Egípcia de WPS",
  siteName: "FEW"
};
```

O site consulta a API a cada 15 segundos. Também existe um botão de atualização manual.

### 3. Publicar no GitHub Pages

1. Crie uma conta em https://github.com/ se ainda não tiver.
2. Crie um repositório chamado `few-site`.
3. Envie os arquivos e pastas desta pasta para a raiz do repositório. Não envie o ZIP fechado.
4. No repositório, abra **Settings → Pages**.
5. Em **Build and deployment**, selecione **Deploy from a branch**.
6. Escolha a branch `main` e a pasta `/ (root)`, depois salve.
7. Aguarde o GitHub gerar o endereço público do site.

## Observações importantes

- A prévia demonstrativa aparece apenas quando `apiUrl` está vazia. Ela não representa dados reais.
- O site é somente de consulta. Não há login administrativo nem ações para editar campeonatos.
- A atualização ocorre por consulta periódica; não é sincronização instantânea por push.
- A classificação geral é calculada a partir das partidas finalizadas e dos placares recebidos. Para formatos com grupos, ida/volta, critérios especiais e mata-mata, a tabela exibida nesta primeira versão é um resumo geral, não substitui a tabela oficial de cada grupo ou chave.
- O serviço público filtra propriedades para não retornar configurações privadas, webhooks, logs, backups ou dados internos do Manager.
- Antes de divulgar o endereço, confira o endpoint público e os dados que você deseja exibir.
