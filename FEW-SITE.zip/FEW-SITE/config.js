/* FEW SITE — configuração pública
 * Cole aqui a URL da implantação do serviço PUBLIC_API.gs.
 * Deixe vazio para abrir a demonstração visual local.
 */
window.FEW_CONFIG = {
  apiUrl: "",
  refreshSeconds: 15,
  federationName: "Federação Egípcia de WPS",
  siteName: "FEW"
};
